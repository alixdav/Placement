import { getCurrentProfile, getListings } from '@/lib/data';
import { rankListings } from '@/lib/distance';
import { isSupabaseConfigured } from '@/lib/supabase';
import { Logo } from '@/components/Logo';
import { ContextBar } from '@/components/ContextBar';
import { ListingCard } from '@/components/ListingCard';

// This is a Server Component. It loads the current user's profile and the
// listings, ranks the listings by distance to that user's workplace, then
// renders a view that is personalised end to end. No toggle is shown: a
// doctor opens straight into the hospital ranked, green view, a graduate into
// the office ranked, purple view.

export default async function ListingsPage() {
  const profile = await getCurrentProfile();
  const listings = await getListings();
  const ranked = rankListings(listings, profile);

  const isDoctor = profile.user_type === 'doctor';
  const accentText = isDoctor ? 'text-green' : 'text-grad';
  const usingLiveData = isSupabaseConfigured();

  return (
    <div className="min-h-screen bg-offwhite">
      {/* Nav */}
      <header className="border-b border-cream-border bg-white">
        <div className="mx-auto flex max-w-shell items-center justify-between px-6 py-4">
          <Logo userType={profile.user_type} />
          <nav className="flex items-center gap-6 text-sm text-ink-mid">
            <span className={`font-medium ${accentText}`}>Find a room</span>
            <span>List your room</span>
            <span>Handovers</span>
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-cream text-xs font-medium text-green-dark">
              {profile.display_name.slice(0, 1)}
            </span>
          </nav>
        </div>
      </header>

      <ContextBar profile={profile} />

      {/* Illustrative data notice. Remove once live data is flowing. */}
      {!usingLiveData && (
        <div className="bg-cream/60">
          <div className="mx-auto max-w-shell px-6 py-2 text-xs text-cream-body">
            Showing illustrative placeholder listings. Connect Supabase in
            .env.local to switch to live data.
          </div>
        </div>
      )}

      <main className="mx-auto max-w-shell px-6 py-8">
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-[260px_1fr]">
          {/* Sidebar */}
          <aside className="lg:sticky lg:top-8 lg:self-start">
            <p className="text-[11px] uppercase tracking-label text-ink-light">
              Ranked by distance to
            </p>
            <h2 className="mt-1 font-display text-2xl leading-tight text-green-dark">
              {profile.workplace_name}
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-ink-mid">
              Every room below is measured from your{' '}
              {isDoctor ? 'hospital' : 'office'}, not the city centre. Closest
              first.
            </p>
            <div className="mt-4 rounded-lg border border-cream-border bg-white p-3 text-sm text-ink-mid">
              <span className="font-medium text-ink">{ranked.length} rooms</span>{' '}
              in {profile.next_city} for your{' '}
              {new Date(profile.move_date).toLocaleDateString('en-GB', {
                month: 'long',
              })}{' '}
              move.
            </div>
          </aside>

          {/* Listings */}
          <section>
            <div className="mb-4 flex items-baseline justify-between">
              <h1 className="font-display text-3xl text-green-dark">
                Closest to {profile.workplace_name}
              </h1>
            </div>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
              {ranked.map((listing, i) => (
                <ListingCard
                  key={listing.id}
                  listing={listing}
                  profile={profile}
                  rank={i + 1}
                />
              ))}
            </div>
          </section>
        </div>
      </main>

      <footer className="border-t border-cream-border bg-white">
        <div className="mx-auto max-w-shell px-6 py-6 text-[11px] uppercase tracking-footer text-ink-light">
          placementliving.com
        </div>
      </footer>
    </div>
  );
}
